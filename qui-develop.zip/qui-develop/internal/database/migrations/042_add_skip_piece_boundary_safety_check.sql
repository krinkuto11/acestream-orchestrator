ALTER TABLE cross_seed_settings ADD COLUMN skip_piece_boundary_safety_check BOOLEAN NOT NULL DEFAULT 1;
