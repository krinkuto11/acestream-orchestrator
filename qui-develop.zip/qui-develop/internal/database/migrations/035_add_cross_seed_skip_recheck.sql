ALTER TABLE cross_seed_settings ADD COLUMN skip_recheck BOOLEAN NOT NULL DEFAULT 0;
